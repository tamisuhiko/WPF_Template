﻿using System.Windows.Media;

namespace $safeprojectname$.Models
{
    public struct DataColor
    {
        public Brush Color { get; set; }
    }
}
