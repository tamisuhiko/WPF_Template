﻿namespace Wpf.Ui.FontMapper;

record GitTag(string Ref, string Node_Id, string Url);
