﻿using System.Reflection;

namespace Wpf.Ui.Gallery;

class GalleryAssembly
{
    public static Assembly Asssembly => Assembly.GetExecutingAssembly();
}
