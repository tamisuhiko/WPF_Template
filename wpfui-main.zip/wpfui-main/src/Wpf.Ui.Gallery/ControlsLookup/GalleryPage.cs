﻿namespace Wpf.Ui.Gallery.ControlsLookup;

record GalleryPage(string Name, string Description, SymbolRegular Icon, Type PageType);
