﻿namespace Wpf.Ui.Common;

/// <summary>
/// TODO
/// </summary>
public enum FontTypography
{
    Caption,
    Body,
    BodyStrong,
    Subtitle,
    Title,
    TitleLarge,
    Display
}
