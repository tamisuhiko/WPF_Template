# WPF UI Gallery

**WPF UI Gallery** is a free application available in the _Microsoft Store_, with which you can test all functionalities.  
https://apps.microsoft.com/store/detail/wpf-ui/9N9LKV8R9VGM

```powershell
$ winget install 'WPF UI'
```
